use Training_12DecMumbai

create schema TaxiBooking1

create table TaxiBooking1.Customer
(
CustomerID int Identity(100,1) not null primary key,
CustomerName varchar(20),
Password varchar(20),
ConfirmPassword varchar(20),
PhoneNumber varchar(10),
EmailID varchar(20)
)

drop table TaxiBooking1.Customer
 

select*from TaxiBooking1.Customer

--==Insert Customer
alter procedure TaxiBooking1.Customer_Insert
(
@CustomerID int,
@CustomerName varchar(20),
@Password varchar(20),
@ConfirmPassword varchar(20),

@PhoneNumber varchar(10),
@EmailID varchar(20)
 )
AS
BEGIN
IF(@CustomerID IS NULL OR @CustomerID< 0)
BEGIN
RAISERROR('Customer ID cannot be null or negative',1, 1)
END
ELSE
IF EXISTS (SELECT CustomerID FROM TaxiBooking.Customer WHERE CustomerID = @CustomerID)
BEGIN
INSERT INTO TaxiBooking1.Customer(CustomerName,Password,ConfirmPassword,PhoneNumber,EmailID)
    VALUES(@CustomerName,@Password,@ConfirmPassword,@PhoneNumber,@EmailID)
END
END



exec TaxiBooking1.Customer_Insert 1,'Raju','anusha','anusha','9582861215','raju@gmail.com'
go

select * from TaxiBooking1.Customer


--======= Update Customer--
alter procedure TaxiBooking1.Customer_Update
(
@CustomerID int,
@CustomerName varchar(20),
@Password varchar(20),
@ConfirmPassword varchar(20),
@PhoneNumber varchar(10),
@EmailID varchar(20)
)
AS
BEGIN
IF(@CustomerID IS NULL OR @CustomerID< 0)
BEGIN
RAISERROR('Customer ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT CustomerID FROM TaxiBooking1.Customer WHERE CustomerID = @CustomerID)
BEGIN
RAISERROR('Customer ID cannot update',1, 1)
END
BEGIN
update TaxiBooking1.Customer set 
								CustomerName=@CustomerName,
								Password=@Password,
							    ConfirmPassword=@ConfirmPassword,
							   PhoneNumber=@PhoneNumber,
							   EmailID=@EmailID
							   where CustomerID = @CustomerID
						 
END
END
END


exec TaxiBooking1.Customer_Update 102,'Raju','anusha','anusha','9582861215','raju@gmail.com'
go
select * from TaxiBooking1.Customer


---===============Delete Customer
create procedure TaxiBooking1.Customer_Delete
(
@CustomerID int
)
AS
BEGIN
IF(@CustomerID IS NULL OR @CustomerID < 0)
BEGIN
RAISERROR('Customer ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT CustomerID FROM TaxiBooking1.Customer WHERE CustomerID = @CustomerID)
BEGIN
delete from TaxiBooking1.Customer where (CustomerID = @CustomerID)
END
END
END

exec TaxiBooking1.Customer_Delete 100
go

select * from TaxiBooking1.Customer


----================= search Customer
alter procedure TaxiBooking1.Customer_Search
(
  @CustomerID int
  )
AS
BEGIN
IF(@CustomerID IS NULL OR @CustomerID < 0)
BEGIN
RAISERROR('Customer ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT CustomerID FROM TaxiBooking1.Customer WHERE CustomerID = @CustomerID)
BEGIN
RAISERROR('Customer ID not searched',1, 1)
END
BEGIN
SELECT CustomerID,CustomerName,PhoneNumber,EmailID FROM TaxiBooking1.Customer where CustomerID=@CustomerID
END
END
END

exec TaxiBooking1.Customer_Search 100
go
select * from TaxiBooking1.Customer