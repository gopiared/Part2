use Training_12DecMumbai



create table TaxiBooking1.Taxi
(
TaxiID int not null identity(10000,1) primary key,
TaxiModel varchar(20),
Color varchar(20),
RegisterNumber varchar(10),
TaxiType varchar(20)
)

select*from TaxiBooking1.Taxi
drop table TaxiBooking1.Taxi


--==Insert Taxi
create procedure TaxiBooking1.Taxi_Insert
(
@TaxiID int,
@TaxiModel varchar(20),
@Color varchar(20),
@RegisterNumber varchar(10),
@TaxiType varchar(20)
 )
AS
BEGIN
IF( @TaxiID IS NULL OR  @TaxiID < 0)
BEGIN
RAISERROR('Taxi ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT TaxiID FROM TaxiBooking1.Taxi WHERE TaxiID = @TaxiID)
BEGIN
RAISERROR('Taxi ID already exists',1, 1)
END
ELSE
BEGIN
INSERT INTO TaxiBooking1.Taxi(TaxiModel,Color,TaxiType,RegisterNumber)
    VALUES(@TaxiModel,@Color,@TaxiType,@RegisterNumber)
END
END
END

exec TaxiBooking1.Taxi_Insert 1,'benz','red','3seat','ap16cx6822'
go

select * from TaxiBooking1.Taxi


--======= Update Admin--
create procedure TaxiBooking1.Taxi_Update
(
@TaxiID int,
@TaxiModel varchar(20),
@Color varchar(20),
@RegisterNumber varchar(10),
@TaxiType varchar(20)
)
AS
BEGIN
IF(@TaxiID IS NULL OR @TaxiID< 0)
BEGIN
RAISERROR('Taxi ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT TaxiID FROM TaxiBooking1.Taxi WHERE TaxiID = @TaxiID)
BEGIN
RAISERROR('Taxi ID details is updated',1, 1)
END
BEGIN
update TaxiBooking1.Taxi set  TaxiModel=@TaxiModel,
							   Color=@Color,
							   RegisterNumber=@RegisterNumber,
							    TaxiType=@TaxiType
							   where TaxiID = @TaxiID
						 
END
END
END


exec TaxiBooking1.Taxi_Update 10000,'benz','red','4seat','ap16cx6822'
go
select * from TaxiBooking1.Taxi


---===============Delete Customer
create procedure TaxiBooking1.Taxi_Delete
(
 @TaxiID int
)
AS
BEGIN
IF(@TaxiID IS NULL OR @TaxiID < 0)
BEGIN
RAISERROR('Taxi ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT TaxiID FROM TaxiBooking1.Taxi WHERE TaxiID = @TaxiID)
BEGIN
RAISERROR('Taxi ID can be deleted',1, 1)
END
BEGIN
delete from TaxiBooking1.Taxi where (TaxiID = @TaxiID)
END
END
END

exec TaxiBooking1.Taxi_Delete 10000
go

select * from TaxiBooking1.Taxi


----================= search Customer
create procedure TaxiBooking1.Taxi_Search
(
 @TaxiID int
  )
AS
BEGIN
IF(@TaxiID IS NULL OR @TaxiID < 0)
BEGIN
RAISERROR('Taxi ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT TaxiID FROM TaxiBooking1.Taxi WHERE TaxiID = @TaxiID)
BEGIN
RAISERROR('Taxi ID is searched',1, 1)
END
BEGIN
SELECT * FROM TaxiBooking1.Taxi where TaxiID=@TaxiID
END
END
END
exec TaxiBooking1.Taxi_Search 10000
go

select * from TaxiBooking1.Taxi

