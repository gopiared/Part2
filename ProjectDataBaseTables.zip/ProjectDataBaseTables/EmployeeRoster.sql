use Training_12DecMumbai

create schema TaxiBooking1

create table TaxiBooking1.EmployeeRoster
(
RosterID int not null identity(100,1) primary key,
FromDate Date,
ToDate Date,
InTime DateTime,
OutTime DateTime,
EmployeeID int foreign key references TaxiBooking1.Employee(EmployeeID)
)
select*from TaxiBooking1.EmployeeRoster

drop table TaxiBooking1.EmployeeRoster

--==Insert Employee
alter procedure TaxiBooking1.EmployeeRoster_Insert
(
@RosterID int,
@FromDate Date,
@ToDate Date,
@InTime DateTime,
@OutTime DateTime,
@EmployeeID int
 )
AS
BEGIN
IF( @RosterID IS NULL OR  @RosterID < 0)
BEGIN
RAISERROR('Roster ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT RosterID FROM TaxiBooking1.EmployeeRoster WHERE RosterID = @RosterID)
BEGIN
RAISERROR('Roster ID already exists',1, 1)
END
ELSE
BEGIN
INSERT INTO TaxiBooking1.EmployeeRoster(FromDate,ToDate,InTime,OutTime,EmployeeID) 
                values (@FromDate,@ToDate,@InTime,@OutTime,@EmployeeID)
END
END
END

exec TaxiBooking1.EmployeeRoster_Insert 1,'01-10-2012','02-10-2012','12:12','10:10',101
go

select * from TaxiBooking1.EmployeeRoster


--======= Update Employee--
alter procedure TaxiBooking1.EmployeeRoster_Update
(
@RosterID int,
@FromDate Date,
@ToDate Date,
@InTime DateTime,
@OutTime DateTime,
@EmployeeID int
)
AS
BEGIN
IF(@RosterID IS NULL OR @RosterID< 0)
BEGIN
RAISERROR('Roster ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT RosterID FROM TaxiBooking1.EmployeeRoster WHERE RosterID = @RosterID)
BEGIN
RAISERROR('Roster ID is updated',1, 1)
END
BEGIN
update TaxiBooking1.EmployeeRoster set FromDate=FromDate,
							   ToDate=@ToDate,
							   InTime=@InTime,
							   OutTime=@OutTime 
							   where RosterID = @RosterID
						 
END
END
END

drop procedure TaxiBooking1.EmployeeRoster_Update
exec TaxiBooking1.EmployeeRoster_Update 1,'01-10-2012','10-10-1010','12:01','10:10',101
go
select * from TaxiBooking1.EmployeeRoster


---===============Delete Employee
create procedure TaxiBooking1.EmployeeRoster_Delete
(
@RosterID int
)
AS
BEGIN
IF(@RosterID IS NULL OR @RosterID < 0)
BEGIN
RAISERROR('Roster ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT RosterID FROM TaxiBooking1.EmployeeRoster WHERE RosterID = @RosterID)
BEGIN
RAISERROR('Roster ID is deleted',1, 1)
END
BEGIN
delete from TaxiBooking1.EmployeeRoster where (RosterID = @RosterID)
END
END
END

exec TaxiBooking1.EmployeeRoster_Delete 101
go

select * from TaxiBooking1.EmployeeRoster


----================= search Employee
create procedure TaxiBooking1.EmployeeRoster_Search
(
 @RosterID int
  )
AS
BEGIN
IF(@RosterID IS NULL OR @RosterID < 0)
BEGIN
RAISERROR('Roster ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT RosterID FROM TaxiBooking1.EmployeeRoster WHERE RosterID = @RosterID)
BEGIN
RAISERROR('Roster ID Searched is',1, 1)
END
BEGIN
SELECT * FROM TaxiBooking1.EmployeeRoster where RosterID=@RosterID
END
END
END

exec TaxiBooking1.EmployeeRoster_Search 100
go