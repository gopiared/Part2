use Training_12DecMumbai



create table TaxiBooking1.Booking
(
BookingID int not null identity(100000,1) primary key,
TaxiID int foreign key REFERENCES TaxiBooking1.Taxi(TaxiID),
CustomerID int foreign key references TaxiBooking1.Customer(CustomerID),
BookingDate date,
TripDate date,
StartTime datetime,
EndTime datetime,
SourceAddress varchar(100),
DestinationAddress varchar(100),

)

select*from TaxiBooking1.Booking
drop table TaxiBooking1.Admin


--==Insert Taxi
create procedure TaxiBooking1.Booking_Insert
(
@BookingID int,
@TaxiID int,
@CustomerID int,
@BookingDate date,
@TripDate date,
@StartTime datetime,
@EndTime datetime,
@SourceAddress varchar(100),
@DestinationAddress varchar(100)
)
AS
BEGIN
IF( @BookingID IS NULL OR  @BookingID < 0)
BEGIN
RAISERROR('Booking ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT BookingID FROM TaxiBooking1.Booking WHERE BookingID = @BookingID)
BEGIN
RAISERROR('Booking ID already exists',1, 1)
END
ELSE
BEGIN
INSERT INTO TaxiBooking1.Booking(TaxiID,CustomerID,BookingDate,TripDate,StartTime,EndTime,SourceAddress,DestinationAddress)
    VALUES(@TaxiID,@CustomerID,@BookingDate,@TripDate,@StartTime,@EndTime,@SourceAddress,@DestinationAddress)
END
END
END

exec TaxiBooking1.Booking_Insert 1,10001,101,'12-10-1202','12-10-1202','12:25','12:25','krishna','hyderabad'
go
select * from TaxiBooking1.Booking
select * from TaxiBooking1.Customer
select * from TaxiBooking1.EmployeeRoster

--======= Update Admin--
create procedure TaxiBooking1.Booking_Update
(
@BookingID int,
@TaxiID int,
@CustomerID int,
@BookingDate date,
@TripDate date,
@StartTime datetime,
@EndTime datetime,
@SourceAddress varchar(100),
@DestinationAddress varchar(100)
)
AS
BEGIN
IF(@BookingID IS NULL OR  @BookingID < 0)
BEGIN
RAISERROR('Booking ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT BookingID FROM TaxiBooking1.Booking WHERE BookingID = @BookingID)
BEGIN
RAISERROR('Booking ID details is updated',1, 1)
END
BEGIN
update TaxiBooking1.Booking set  TaxiID=@TaxiID,
								CustomerID =@CustomerID,
							    BookingDate=@BookingDate,
								TripDate=@TripDate,
								StartTime=@StartTime,
								EndTime=@EndTime,
								SourceAddress=@SourceAddress,
								DestinationAddress=@DestinationAddress
							   where BookingID = @BookingID
						 
END
END
END


exec TaxiBooking1.Booking_Update 100000,10001,101,'12-10-1202','12-10-1202','12:25','12:25','VIJAYAVADA','hyderabad'
go
select * from TaxiBooking1.Booking


---===============Delete Customer
create procedure TaxiBooking1.Booking_Delete
(
 @BookingID int
)
AS
BEGIN
IF(@BookingID IS NULL OR @BookingID < 0)
BEGIN
RAISERROR('Booking ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT BookingID FROM TaxiBooking1.Booking WHERE BookingID = @BookingID)
BEGIN
RAISERROR('Booking ID can be deleted',1, 1)
END
BEGIN
delete from TaxiBooking1.Booking where (BookingID = @BookingID)
END
END
END

exec TaxiBooking1.Booking_Delete 100001
go

select * from TaxiBooking1.Booking


----================= search Customer
create procedure TaxiBooking1.Booking_Search
(
 @BookingID int
  )
AS
BEGIN
IF(@BookingID IS NULL OR @BookingID < 0)
BEGIN
RAISERROR('Booking ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT BookingID FROM TaxiBooking1.Booking WHERE BookingID = @BookingID)
BEGIN
RAISERROR('Booking ID is searched',1, 1)
END
BEGIN
SELECT * FROM TaxiBooking1.Booking where BookingID=@BookingID
END
END
END
exec TaxiBooking1.Booking_Search 100000
go

select * from TaxiBooking1.Booking