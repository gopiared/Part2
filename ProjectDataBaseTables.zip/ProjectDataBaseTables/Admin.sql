use Training_12DecMumbai



create table TaxiBooking1.Admin
(
LoginID varchar(20) primary key,
Password varchar(10),
EmployeeID int foreign key references TaxiBooking1.Employee(EmployeeID),
CustomerID int foreign key references TaxiBooking1.Customer(CustomerID),
Role varchar(10)
)

select*from TaxiBooking1.Admin
drop table TaxiBooking1.Admin


--==Insert Admin
alter procedure TaxiBooking1.Admin_Insert
(
@LoginID varchar(20),
@Password varchar(10),
@EmployeeID int,
@CustomerID int,
@Role varchar(10)
 )
AS
BEGIN
IF( @LoginID IS NULL )
BEGIN
RAISERROR('Login ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT LoginID FROM TaxiBooking1.Admin WHERE LoginID = @LoginID)
BEGIN
RAISERROR('Login ID already exists',1, 1)
END
ELSE
BEGIN
INSERT INTO TaxiBooking1.Admin(LoginID,Password,EmployeeID,CustomerID,Role)
    VALUES(@LoginID,@Password,@EmployeeID,@CustomerID,@Role)
END
END
END

exec TaxiBooking1.Admin_Insert 'admin01','balu',101,101,'maintenence'
go

select * from TaxiBooking1.Admin


--======= Update Admin--
alter procedure TaxiBooking1.Admin_Update
(
@LoginID varchar(20),
@Password varchar(10),
@Role varchar(10)
)
AS
BEGIN
IF(@LoginID IS NULL)
BEGIN
RAISERROR('Login ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT LoginID FROM TaxiBooking1.Admin WHERE LoginID = @LoginID)
BEGIN
RAISERROR('Login ID details is updated',1, 1)
END
BEGIN
update TaxiBooking1.Admin set  Password=@Password,
							   Role=@Role
							   where LoginID = @LoginID
						 
END
END
END


exec TaxiBooking1.Admin_Update 'admin01','ramu','management'
go
select * from TaxiBooking1.Admin


---===============Delete Customer
alter procedure TaxiBooking1.Admin_Delete
(
 @LoginID varchar(20)
)
AS
BEGIN
IF(@LoginID IS NULL )
BEGIN
RAISERROR('Login ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT LoginID FROM TaxiBooking1.Admin WHERE LoginID = @LoginID)
BEGIN
RAISERROR('Login ID can be deleted',1, 1)
END
BEGIN
delete from TaxiBooking1.Admin where (LoginID = @LoginID)
END
END
END

exec TaxiBooking1.Admin_Delete 'admin01'
go

select * from TaxiBooking1.Admin


----================= search Customer
alter procedure TaxiBooking1.Admin_Search
(
 @LoginID varchar(20)
  )
AS
BEGIN
IF(@LoginID IS NULL)
BEGIN
RAISERROR('Login ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT LoginID FROM TaxiBooking1.Admin WHERE LoginID = @LoginID)
BEGIN
RAISERROR('Login ID is searched',1, 1)
END
BEGIN
SELECT * FROM TaxiBooking1.Admin where LoginID=@LoginID
END
END
END
exec TaxiBooking1.Admin_Search 'admin01'
go

select * from TaxiBooking1.Admin