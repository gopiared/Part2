use Training_12DecMumbai

create schema TaxiBooking1

create table TaxiBooking1.Employee
(
EmployeeID int IDENTITY(100,1) not null primary key,
EmployeeName varchar(20),
Designation varchar(20),
PhoneNumber varchar(10),
EmailID varchar(20),
Address varchar(30),
DrivingLicenseNumber varchar(10)
)
select*from TaxiBooking1.Employee
DROP TABLE TaxiBooking.Employee


--==Insert Employee
create procedure TaxiBooking1.Employee_Insert
(
@EmployeeID int,
@EmployeeName varchar(20),
@Designation varchar(20),
@PhoneNumber varchar(10),
@EmailID varchar(20),
@Address varchar(30),
@DrivingLicenseNumber varchar(10)
 )
AS
BEGIN
IF( @EmployeeID IS NULL OR  @EmployeeID < 0)
BEGIN
RAISERROR('Employee ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT EmployeeID FROM TaxiBooking1.Employee WHERE EmployeeID = @EmployeeID)
BEGIN
RAISERROR('Employee ID already exists',1, 1)
END
ELSE
BEGIN
INSERT INTO TaxiBooking1.Employee(EmployeeName,Designation,PhoneNumber,EmailID,Address,DrivingLicenseNumber)
    VALUES(@EmployeeName,@Designation,@PhoneNumber,@EmailID,@Address,@DrivingLicenseNumber)
END
END
END

exec TaxiBooking1.Employee_Insert 1,'Raju','Driver','9582861215','raju@gmail.com','Hyderabad','Ab1545'
go

select * from TaxiBooking1.Employee


--======= Update Employee--
create procedure TaxiBooking1.Employee_Update
(
 @EmployeeID int,
@EmployeeName varchar(20),
@Designation varchar(20),
@PhoneNumber varchar(10),
@EmailID varchar(20),
@Address varchar(30),
@DrivingLicenseNumber varchar(10)
)
AS
BEGIN
IF(@EmployeeID IS NULL OR @EmployeeID< 0)
BEGIN
RAISERROR('Employee ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT EmployeeID FROM TaxiBooking1.Employee WHERE EmployeeID = @EmployeeID)
BEGIN
update TaxiBooking1.Employee set EmployeeName=@EmployeeName,
						       Designation=@Designation,
							   PhoneNumber=@PhoneNumber,
							   EmailID=@EmailID,
							   Address=@Address,
							   DrivingLicenseNumber=@DrivingLicenseNumber where EmployeeID = @EmployeeID
						 
END
END
END

drop procedure TaxiBooking1.Employee_Update
exec TaxiBooking1.Employee_Update 100,'Raju','cleaning','9582861000','raju@gmail.com','Hyderabad','Ab1545'
go
select * from TaxiBooking1.Employee


---===============Delete Employee
create procedure TaxiBooking1.Employee_Delete
(
@EmployeeID int
)
AS
BEGIN
IF(@EmployeeID IS NULL OR @EmployeeID < 0)
BEGIN
RAISERROR('Employee ID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT EmployeeID FROM TaxiBooking1.Employee WHERE EmployeeID = @EmployeeID)
BEGIN
delete from TaxiBooking1.Employee where (EmployeeID = @EmployeeID)
END
END
END

exec TaxiBooking1.Employee_Delete 100
go

select * from TaxiBooking1.Employee


----================= search Employee
create procedure TaxiBooking1.Employee_Search
(
  @EmployeeID int
 
  )
AS
BEGIN
IF(@EmployeeID IS NULL OR @EmployeeID < 0)
BEGIN
RAISERROR('EmployeeID cannot be null or negative',1, 1)
END
ELSE
BEGIN
IF EXISTS (SELECT EmployeeID FROM TaxiBooking1.Employee WHERE EmployeeID = @EmployeeID)
BEGIN
SELECT * FROM TaxiBooking1.Employee where EmployeeID=@EmployeeID
END
END
END

exec TaxiBooking1.Employee_Search 101
go